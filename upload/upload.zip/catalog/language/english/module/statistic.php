<?php
$_['entry_online']    = 'Online';
$_['entry_today']    = 'Visited Today';
$_['entry_yesterday']    = 'Visited yesterday';
$_['entry_lastmonth']    = 'Visited last month';
$_['entry_total']    = 'Total visit';
