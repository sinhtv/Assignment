<?php
// Text
$_['text_title'] = 'Free Checkout';