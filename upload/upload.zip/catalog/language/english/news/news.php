<?php
$_['text_published_at']    = 'Published at';
$_['text_on']    = 'on';
$_['text_views']    = 'Views';
