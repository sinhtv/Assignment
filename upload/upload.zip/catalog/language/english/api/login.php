<?php
// Text
$_['text_success'] = 'Success: API session successfully started!';

// Error
$_['error_key']  = 'Warning: Incorrect API Key!';
$_['error_ip']   = 'Warning: Your IP %s is not allowed to access this API!';
