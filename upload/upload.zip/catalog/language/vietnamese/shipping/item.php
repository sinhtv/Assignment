<?php
// Text
$_['text_title']       = 'Mỗi sản phẩm';
$_['text_description'] = 'Giá vận chuyển trên mỗi sản phẩm';