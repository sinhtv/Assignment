<?php
// Text
$_['text_title']    = 'Australia Post';
$_['text_express']  = 'Express';
$_['text_standard'] = 'Tiêu chuẩn';
$_['text_eta']      = 'vài ngày';