<?php
// Text
$_['text_title']       = 'Nhận hàng';
$_['text_description'] = 'Nhận Hàng tại cửa hàng';