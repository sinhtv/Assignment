<?php
// Text
$_['text_subject']  = 'Bạn đã gửi phiếu quà tặng từ %s';
$_['text_greeting'] = 'Chúc mừng, bạn nhận được phiếu quà tặng trị giá %s';
$_['text_from']     = 'Phiếu quà tặng được gửi đến bạn bởi %s';
$_['text_message']  = 'Với lời nhắn';
$_['text_redeem']   = 'Để sử dụng phiếu quà tặng, hãy ghi lại mã <b>%s</b> sau đó nhấn vào đường dẫn bên dưới để chọn sản phẩm bạn muốn mua và sử dụng mã trên để thanh toán đơn hàng. Bạn cũng có thể nhập mã phiếu quà tặng trong trang Giỏ hàng trước khi thực hiện thanh toán.';
$_['text_footer']   = 'Vui lòng phản hồi thư này nếu bạn có bất kì câu hỏi nào.';