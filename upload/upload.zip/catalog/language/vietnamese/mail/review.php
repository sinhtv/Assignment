<?php
// Text
$_['text_subject']	= '%s - Đánh giá sản phẩm';
$_['text_waiting']	= 'Bạn có một đánh giá về sản phẩm.';
$_['text_product']	= 'Sản phẩm: %s';
$_['text_reviewer']	= 'Người gửi: %s';
$_['text_rating']	= 'Điểm: %s';
$_['text_review']	= 'Nội dung:';