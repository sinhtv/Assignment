<?php
// Text
$_['text_subject']  = '%s - Cộng tác bán hàng';
$_['text_welcome']  = 'Cám ơn bạn đã tham gia chương trình Cộng tác bán hàng!';
$_['text_login']                = 'Tài khoản của bạn đã được tạo và bạn có thể đăng nhập bằng Email và mật khẩu theo đường dẫn sau:';
$_['text_approval'] = 'Bạn có thể đăng nhập vào tài khoản Cộng tác viên bằng email và mật khẩu theo đường dẫn sau:';
$_['text_services'] = 'Sau khi đăng nhập bạn có thể tạo mã giới thiệu và xem số tiền hoa hồng mà bạn đã kiếm được...';
$_['text_thanks']   = 'Trân trọng cám ơn!';
$_['text_new_affiliate']        = 'Cộng tác viên mới';
$_['text_signup']		        = 'Cộng tác viên vừa mới đăng ký:';
$_['text_store']		        = 'Cửa hàng:';
$_['text_firstname']	        = 'Tên:';
$_['text_lastname']		        = 'Họ:';
$_['text_company']		        = 'Công ty:';
$_['text_email']		        = 'E-Mail:';
$_['text_telephone']	        = 'Điện thoại:';
$_['text_website']		        = 'Trang web:';
$_['text_order_id']             = 'Mã đơn hàng:';
$_['text_transaction_subject']  = '%s - Hoa hồng bán hàng';
$_['text_transaction_received'] = 'Bạn vừa nhận được %s tiền hoa hồng!';
$_['text_transaction_total']    = 'Tổng số tiền hoa hồng của bạn hiện tại là %s.';
