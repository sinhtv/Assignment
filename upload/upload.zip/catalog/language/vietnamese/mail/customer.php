<?php
// Text
$_['text_subject']  = '%s - Cám ơn bạn đã đăng kí';
$_['text_welcome']  = 'Chào mừng & Cám ơn bạn đã đăng kí tài khoản tại %s!';
$_['text_login']    = 'Tài khoản của bạn đã được tạo và bạn có thể đăng nhập bằng email và mật khẩu theo đường dẫn sau:';
$_['text_approval'] = 'Tài khoản của bạn phải được phê duyệt trước khi có thể đăng nhập. Khi được chấp nhận bạn có thể đăng nhập bằng địa chỉ email và mật khẩu thông qua đường dẫn sau:';
$_['text_services'] = 'Sau khi đăng nhập, bạn có thể xem lịch sử đặt hàng, in hóa đơn hàng, chỉnh sửa thông tin cá nhân...';
$_['text_thanks']   = 'Trân trọng cám ơn!';
$_['text_new_customer']   = 'Khách hàng mới';
$_['text_signup']         = 'Khách hàng vừa mới đăng ký:';
$_['text_website']        = 'Trang web:';
$_['text_customer_group'] = 'Nhóm:';
$_['text_firstname']      = 'Tên:';
$_['text_lastname']       = 'Họ:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = 'Điện thoại:';
