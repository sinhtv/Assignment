<?php
// Text
$_['text_success']     = 'Thành công: Tiền tệ của bạn đã được thay đổi!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập API!';
$_['error_currency']   = 'Cảnh báo: Mã tiền tệ là không hợp lệ!';