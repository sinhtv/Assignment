<?php
// Text
$_['text_success']     = 'Thành công: Quà tặng phiếu giảm giá của bạn đã được áp dụng!';
$_['text_cart']        = 'Thành công: Bạn đã cập nhật giỏ hàng.!';
$_['text_for']         = '%s phiếu quà tặng cho %s';

// Error
$_['error_permission'] = 'Cảnh báp: Bạn không có quyền truy cập API!';
$_['error_voucher']    = 'Cảnh báo : Phiếu quà tặng không hợp lệ hoặc số dư đã được sử dụng hết!';
$_['error_to_name']    = 'Tên người nhận phải từ 1 đến 64 kí tự!';
$_['error_from_name']  = 'Tên của bạn phải từ 1 đến 64 ký tự!';
$_['error_email']      = 'Đại chỉ email không hợp lệ!';
$_['error_theme']      = 'Bạn phải chọ một giao diện!';
$_['error_amount']     = 'Số tiền phải từ %s đến %s!';
