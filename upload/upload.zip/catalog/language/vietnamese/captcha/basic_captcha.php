<?php
// Heading
$_['heading_title'] = 'Mã bảo vệ';

// Entry
$_['entry_captcha'] = 'Nhập mã bảo vệ';

// Error
$_['error_captcha'] = 'Mã bảo vệ không đúng!';
