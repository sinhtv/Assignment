<?php
// Heading 
$_['heading_title']   = 'Quản lý tải về';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_downloads']  = 'Tải về';
$_['text_empty']      = 'Bạn không có tải về nào trước đó!';

// Column
$_['column_order_id']   = 'Mã';
$_['column_name']       = 'Tên';
$_['column_size']       = 'Dung lượng';
$_['column_date_added'] = 'Ngày tạo';