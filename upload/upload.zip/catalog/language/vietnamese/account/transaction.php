<?php
// Heading 
$_['heading_title']      = 'Lịch sử giao dịch';

// Column
$_['column_date_added']  = 'Ngày tạo';
$_['column_description'] = 'Mô tả';
$_['column_amount']      = 'Số tiền (%s)';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_transaction']   = 'Lịch sử giao dịch';
$_['text_total']         = 'Số dư hiện tại:';
$_['text_empty']         = 'Bạn chưa có giao dịch nào!';