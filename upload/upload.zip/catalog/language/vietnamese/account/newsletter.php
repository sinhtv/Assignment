<?php
// Heading 
$_['heading_title']    = 'Đăng ký nhận thư thông báo';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_newsletter']  = 'Thư thông báo';
$_['text_success']     = 'Thành công: Bạn đã đăng ký nhận thư thông báo!';

// Entry
$_['entry_newsletter'] = 'Đăng ký';
