<?php
// Heading 
$_['heading_title']      = 'Điểm thưởng';

// Column
$_['column_date_added']  = 'Ngày tạo';
$_['column_description'] = 'Mô tả';
$_['column_points']      = 'Điểm';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_reward']        = 'Điểm thưởng';
$_['text_total']         = 'Tổng điểm thưởng của bạn:';
$_['text_empty']         = 'Bạn không có điểm thưởng nào!';