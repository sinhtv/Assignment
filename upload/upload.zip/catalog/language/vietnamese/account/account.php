<?php
// Heading 
$_['heading_title']      = 'Thông tin tài khoản';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_my_account']    = 'Tài khoản';
$_['text_my_orders']     = 'Đơn hàng';
$_['text_my_newsletter'] = 'Thư thông báo';
$_['text_edit']          = 'Cập nhật thông tin tài khoản';
$_['text_password']      = 'Thay đổi mật khẩu';
$_['text_address']       = 'Cập nhật địa chỉ';
$_['text_wishlist']      = 'Danh sách yêu thích';
$_['text_order']         = 'Lịch sử đặt hàng';
$_['text_download']      = 'Tải về';
$_['text_reward']        = 'Điểm thưởng'; 
$_['text_return']        = 'Đổi hàng'; 
$_['text_transaction']   = 'Lịch sử giao dịch'; 
$_['text_newsletter']    = 'Đăng ký / Hủy đăng ký thông báo';
$_['text_recurring']     = 'Thanh toán định kỳ';
$_['text_transactions']  = 'Lịch sử giao dịch';