<?php
// Text
$_['text_paid_amazon'] 			= 'Thanh toán trên Amazon';
$_['text_total_shipping'] 		= 'Vận chuyển';
$_['text_total_shipping_tax'] 	= 'Thuế vận chuyển';
$_['text_total_giftwrap'] 		= 'Phiếu quà tặng';
$_['text_total_giftwrap_tax'] 	= 'Thuế phiếu quà tặng';
$_['text_total_sub'] 			= 'Thành tiền';
$_['text_tax'] 					= 'Thiếu';
$_['text_total'] 				= 'Tổng số';