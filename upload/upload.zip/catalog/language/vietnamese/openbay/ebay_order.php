<?php
// Text
$_['text_total_shipping']		= 'Vận chuyển';
$_['text_total_discount']		= 'Giảm giá';
$_['text_total_tax']			= 'Thuế';
$_['text_total_sub']			= 'Thành tiền';
$_['text_total']				= 'Tổng số';
$_['text_smp_id']				= 'Mã số người bán: ';
$_['text_buyer']				= 'Người mua: ';