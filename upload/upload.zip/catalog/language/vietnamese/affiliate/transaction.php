<?php
// Heading
$_['heading_title']      = 'Sản lượng của bạn';

// Column
$_['column_date_added']  = 'Ngày tạo';
$_['column_description'] = 'Mô tả';
$_['column_amount']      = 'Số tiền (%s)';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_transaction']   = 'Các giao dịch của bạn';
$_['text_balance']       = 'Tổng số tiền hoa hồng bạn đã nhận được:';
$_['text_empty']         = 'Bạn không có giao dịch nào!';