<?php
// Heading
$_['heading_title'] = 'Đăng xuất khỏi tài khoản';

// Text
$_['text_message']  = '<p>Bạn đã đăng xuất tài khoản công tác viên.</p>';
$_['text_account']  = 'Tài khoản';
$_['text_logout']   = 'Đăng xuất';