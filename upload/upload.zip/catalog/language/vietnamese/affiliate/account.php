<?php
// Heading 
$_['heading_title']        = 'Tài khoản cộng tác viên';

// Text
$_['text_account']         = 'Tài khoản';
$_['text_my_account']      = 'Tài khoản cộng tác viên';
$_['text_my_tracking']     = 'Thông tin theo dõi';
$_['text_my_transactions'] = 'Thống kê sản lượng';
$_['text_edit']            = 'Thay đổi thông tin tài khoản';
$_['text_password']        = 'Thay đổi mật khẩu';
$_['text_payment']         = 'Cấu hình thanh toán';
$_['text_tracking']        = 'Hiệu chỉnh mã giới thiệu';
$_['text_transaction']     = 'Xem lịch sử bán hàng';