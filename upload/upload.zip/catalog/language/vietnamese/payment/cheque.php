<?php
// Text
$_['text_title']				= 'Thanh toán bằng Séc';
$_['text_instruction']			= 'Hướng dẫn thanht toán';
$_['text_payable']				= 'Người nhận: ';
$_['text_address']				= 'Gửi tới: ';
$_['text_payment']				= 'Đơn hàng của bạn sẽ được thực hiện sau khi chúng tôi nhận được thanh toán.';