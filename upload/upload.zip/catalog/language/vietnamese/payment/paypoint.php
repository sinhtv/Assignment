<?php
// Heading
$_['heading_title']				= 'Cảm ơn bạn đã mua thàng tại %s .... ';

// Text
$_['text_title']				= 'Thẻ Credit Card / Debit Card';
$_['text_response']				= 'Phản hồi từ PayPoint:';
$_['text_success']				= '... thanh toán của bạn đã được nhận.';
$_['text_success_wait']			= '<b><span style="color: #FF0000">Vui lòng đợi...</span></b> cho đến khi chúng tôi xử lý xong đơn hàng của bạn.<br>Nếu trình chuyện không tự động chuyển sau 10 giây, vui lòng <a href="%s">nhấn vào đây</a>.';
$_['text_failure']				= '... Thanh toán của bạn đã bị hủy!';
$_['text_failure_wait']			= '<b><span style="color: #FF0000">Vui lòng đợi...</span></b><br>Nếu trình chuyện không tự động chuyển sau 10 giây, vui lòng <a href="%s">nhấn vào đây</a>.';