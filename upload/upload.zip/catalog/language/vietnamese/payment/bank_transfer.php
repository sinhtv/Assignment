<?php

// Text
$_['text_title']				= 'Chuyển khoản ngân hàng';
$_['text_instruction']			= 'Hướng dẫn chuyển khoản';
$_['text_description']			= 'Làm ơn chuyển khoản số tiền thanh toán tới tài khoản ngân hàng sau.';
$_['text_payment']				= 'Đơn hàng của bạn sẽ được chuyển ngay khi chúng tôi xác nhận thanh toán thành công.';