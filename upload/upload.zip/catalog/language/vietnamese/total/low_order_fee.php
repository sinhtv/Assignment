<?php
$_['text_low_order_fee'] = 'Phí đặt đơn hàng nhỏ:';
?>