<?php
// Heading 
$_['heading_title'] = 'Sử dụng phiếu quà tặng';

// Text
$_['text_voucher']  = 'Phiếu quà tặng(%s):';
$_['text_success']  = 'Thành công: Phiếu quà tặng của bạn đã được áp dụng!';

// Entry
$_['entry_voucher'] = 'Nhập mã phiếu quà tặng của bạn tại đây:';

// Error
$_['error_voucher'] = 'Lỗi: Phiếu quà tặng không tồn tại hoặc đã được sử dụng!';
$_['error_empty']   = 'Lỗi: Vui lòng nhập mã phiếu quà tặng!';