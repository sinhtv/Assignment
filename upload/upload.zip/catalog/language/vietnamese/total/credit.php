<?php
$_['text_credit']   = 'Thẻ tín dụng';
$_['text_order_id'] = 'Mã đơn hàng: #%s';
?>