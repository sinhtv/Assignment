<?php
// Text
$_['text_items']    = '%s sản phẩm - %s';
$_['text_empty']    = 'Giỏ hàng đang trống!';
$_['text_cart']     = 'Xem giỏ hàng';
$_['text_checkout'] = 'Thanh toán';
$_['text_recurring']  = 'Hồ sơ thanh toán';