<?php
// Heading
$_['heading_title']     = 'Bảo trì hệ thống';

// Text
$_['text_maintenance']  = 'Bảo trì hệ thống';
$_['text_message']      = '<h1 style="text-align:center;">Website đang được bảo trì hệ thống định kì. <br/>Chúng tôi sẽ hoạt động lại sớm nhất có thể. Vui lòng quay lại sau! Trân trọng cám ơn!</h1>';