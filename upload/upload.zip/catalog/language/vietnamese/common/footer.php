<?php

// Text
$_['text_information']  = 'Thông tin';
$_['text_service']      = 'Dịch vụ khách hàng';
$_['text_extra']        = 'Tiện ích';
$_['text_contact']      = 'Liên hệ';
$_['text_return']       = 'Đổi hàng';
$_['text_sitemap']      = 'Sơ đồ trang';
$_['text_manufacturer'] = 'Nhà sản xuất';
$_['text_voucher']      = 'Phiếu quà tặng';
$_['text_affiliate']    = 'Cộng tác bán hàng';
$_['text_special']      = 'Khuyến mãi';
$_['text_account']      = 'Tài khoản';
$_['text_order']        = 'Lịch sử đặt hàng';
$_['text_wishlist']     = 'Danh sách yêu thích';
$_['text_newsletter']   = 'Thư thông báo';
$_['text_powered']      = '%s Bản quyền <a href="http://www.opencart.vn">OpenCart</a> &copy; %s';