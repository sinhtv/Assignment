<?php
// Text
$_['text_home']     = 'Trang chủ';
$_['text_wishlist'] = 'Yêu thích (%s)';
$_['text_shopping_cart'] = 'Giỏ hàng';
$_['text_category']      = 'Danh mục';
$_['text_account']       = 'Tài khoản';
$_['text_register']      = 'Đăng ký';
$_['text_login']         = 'Đăng nhập';
$_['text_order']         = 'Lịch sử đặt hàng';
$_['text_transaction']   = 'Lịch sử giao dịch';
$_['text_download']      = 'Tải về';
$_['text_logout']        = 'Đăng xuất';
$_['text_checkout'] = 'Thanh toán';
$_['text_search']        = 'Tìm kiếm';
$_['text_all']           = 'Tất cả';