<?php
// Heading
$_['heading_title']     = 'So sánh sản phẩm';
 
// Text
$_['text_product']      = 'Chi tiết sản phẩm';
$_['text_name']         = 'Sản phẩm';
$_['text_image']        = 'Hình ảnh';
$_['text_price']        = 'Đơn giá';
$_['text_model']        = 'Mã hàng';
$_['text_manufacturer'] = 'Thương hiệu';
$_['text_availability'] = 'Tình Trạng';
$_['text_instock']      = 'Còn hàng';
$_['text_rating']       = 'Đánh giá';
$_['text_reviews']      = 'Dựa vào %s đánh giá.';
$_['text_summary']      = 'Mô tả tóm tắt';
$_['text_weight']       = 'Trọng lượng';
$_['text_dimension']    = 'Kích thước (L x W x H)';
$_['text_compare']      = 'So sánh sản phẩm (%s)';
$_['text_success']      = 'Thành công: Bạn đã thêm sản phẩm <a href="%s">%s</a> vào mục <a href="%s">so sánh</a>!';
$_['text_remove']       = 'Thành công: Bạn đã sửa đổi sản phẩm so sánh của bạn!';
$_['text_empty']        = 'Bạn chưa chọn sản phẩm nào để so sánh.';