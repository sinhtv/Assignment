<?php
// Text
$_['text_upload']    = 'Tệp tin của bạn đã được tải lên!';

// Error
$_['error_filename'] = 'Tên tệp tin phải từ 3 đến 64 ký tự!';
$_['error_filetype'] = 'Không đúng định dạng!';
$_['error_upload']   = 'Bắt buộc phải có tải lên!';
