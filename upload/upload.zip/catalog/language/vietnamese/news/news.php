<?php
$_['text_published_at']    = 'Đăng lúc';
$_['text_on']    = 'ngày';
$_['text_views']    = 'Lượt xem';
