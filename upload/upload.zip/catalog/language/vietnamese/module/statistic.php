<?php
$_['entry_online']    = 'Trực tuyến';
$_['entry_today']    = 'Hôm nay';
$_['entry_yesterday']    = 'Hôm qua';
$_['entry_lastmonth']    = 'Tháng trước';
$_['entry_total']    = 'Tổng truy cập';
