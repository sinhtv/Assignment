<?php
// Heading 
$_['heading_title'] = 'Sản phẩm nổi bật';

// Text
$_['text_tax']      = 'Chưa thuế:';