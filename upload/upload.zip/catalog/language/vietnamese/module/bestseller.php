<?php
// Heading 
$_['heading_title'] = 'Sản phẩm bán chạy';

// Text
$_['text_tax']      = 'Chưa thuế:';