﻿<?php
// Heading 
$_['heading_title'] = 'Trang thông tin';

// Text
$_['text_contact']  = 'Liên hệ';
$_['text_sitemap']  = 'Sơ đồ trang';