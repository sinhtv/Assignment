﻿<?php
// Heading 
$_['heading_title']    = 'Affiliate';

// Text
$_['text_register']    = 'Đăng ký';
$_['text_login']       = 'Đăng nhập';
$_['text_logout']      = 'Đăng xuất';
$_['text_forgotten']   = 'Quên mật khẩu';
$_['text_account']     = 'Tài khoản';
$_['text_edit']        = 'Thay đổi thông tin';
$_['text_password']    = 'Thay đổi mật khẩu';
$_['text_payment']     = 'Cài đặt thanh toán';
$_['text_tracking']    = 'Mã giới thiệu';
$_['text_transaction'] = 'Thống kê';
