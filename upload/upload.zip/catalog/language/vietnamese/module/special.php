<?php
// Heading 
$_['heading_title'] = 'Sản phẩm khuyến mãi';

// Text
$_['text_tax']      = 'Chưa thuế:';